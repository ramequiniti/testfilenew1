package US10001;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.RegistrationPage;
import pages.UserLandingPage;
import util.ReadPropertyFile;

public class RegisterNewCustomerAndADDItemToWishlist {
	@Test
public  void main(){
		/*
		 * Reading inputs from Property file Inputs.properties
		 */
	String email=ReadPropertyFile.readFile("email");
	String custFirstName=ReadPropertyFile.readFile("custFirstName");
	String custLastName=ReadPropertyFile.readFile("custLastName");
	String password=ReadPropertyFile.readFile("password");
	String addrFirstName=ReadPropertyFile.readFile("addrFirstName");
	String addrLastName=ReadPropertyFile.readFile("addrLastName");
	String addressLine1=ReadPropertyFile.readFile("addressLine1");
	String city=ReadPropertyFile.readFile("city");
	String state=ReadPropertyFile.readFile("state");
	String postalCode=ReadPropertyFile.readFile("postalCode");
	String country=ReadPropertyFile.readFile("country");
	String mobileNumber=ReadPropertyFile.readFile("mobileNumber");
	String aliasAddress=ReadPropertyFile.readFile("aliasAddress");
	String productIndex=ReadPropertyFile.readFile("productIndex");
	
	/*
	 * Creating WebDriver for Chrome Browser
	 */
	System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("http://automationpractice.com");
	driver.manage().window().maximize();
	
	/*
	 * Navigate to registration page
	 */
	HomePage home=new HomePage();
	home.navigateToSignInPage(driver);
	home.navigateToRegistrationPage(driver, email);
	
	/*
	 * Register user
	 */
	RegistrationPage registration=new RegistrationPage();
	registration.registerUser(driver, custFirstName, custLastName, password, addrFirstName, addrLastName, addressLine1, city,
			state, postalCode, country, mobileNumber, aliasAddress);
	
	/*
	 * Verify user and add First Product to wishlist
	 */
	UserLandingPage.verifyUserNameInUserLandingPage(driver, custFirstName, custLastName);
	UserLandingPage.addToWishList(driver, productIndex);
	driver.quit();
}
}
