package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class UserLandingPage {
	/*
	 * Defining webElements of this page
	 */
public static WebElement myWishListLink(WebDriver driver){
	return driver.findElement(By.xpath("//a[@title='My wishlists']"));
}
public static WebElement topsellersProduct(WebDriver driver,String index){
	return driver.findElement(By.xpath("//div[@id='best-sellers_block_right']//li["+index+"]//div[@class='product-content']/h5/a[@class='product-name']"));
}

public static WebElement addToWishList(WebDriver driver){
	return driver.findElement(By.xpath("//a[@title='Add to my wishlist']"));
}
public static WebElement addToWishListMessage(WebDriver driver){
	return driver.findElement(By.xpath("//p[text()='Added to your wishlist.']"));
}
public static WebElement userNameText(WebDriver driver){
	return driver.findElement(By.xpath("//a[@title='View my customer account']/span"));
}
/*
 * Verify User name by passing the values of signed in user
 */
public static void verifyUserNameInUserLandingPage(WebDriver driver,String firstName,String lastName){
	try{
	assert userNameText(driver).getText().equals(firstName+" "+lastName):"User name displayed in the UI is mismatched with the given username";
	System.out.println("User name verified successfully..");
	}
	catch(Exception e){
		System.out.println("Exception occurred while verifying username  ");
		e.printStackTrace();
	}
}
/*
 * Adding an Item to WishListss
 */
public static void addToWishList(WebDriver driver,String productIndex){
	try{
	myWishListLink(driver).click();
	topsellersProduct(driver, productIndex).click();
	addToWishList(driver).click();
	Thread.sleep(2000);
	String addtoWishListText=addToWishListMessage(driver).getText();
	assert addtoWishListText.equals("Added to your wishlist."):"Item not added to you wishList";
	System.out.println("Item added to the wishlist..");
	}
	catch(Exception e){
		System.out.println("Exception occurred while adding item to the wishList  ");
		e.printStackTrace();
	}
}
}
