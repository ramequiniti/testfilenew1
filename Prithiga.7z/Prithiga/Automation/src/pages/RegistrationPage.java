package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPage {
	/*
	 * Defining webElements of this page
	 */
public WebElement customerFirstName(WebDriver driver){
	return driver.findElement(By.xpath("//input[@name='customer_firstname']"));
}
public WebElement customerLastName(WebDriver driver){
	return driver.findElement(By.xpath("//input[@id='customer_lastname']"));
}
public WebElement password(WebDriver driver){
	return driver.findElement(By.xpath("//input[@id='passwd']"));
}
public WebElement addressFirstName(WebDriver driver){
	return driver.findElement(By.xpath("//input[@id='firstname']"));
}
public WebElement addressLastName(WebDriver driver){
	return driver.findElement(By.xpath("//input[@id='lastname']"));
}
public WebElement addressLine1(WebDriver driver){
	return driver.findElement(By.xpath("//input[@id='address1']"));
}
public WebElement city(WebDriver driver){
	return driver.findElement(By.xpath("//input[@id='city']"));
}
public WebElement state(WebDriver driver){
	return driver.findElement(By.xpath("//select[@id='id_state']"));
}

public WebElement postalCode(WebDriver driver){
	return driver.findElement(By.xpath("//input[@id='postcode']"));
}
public WebElement country(WebDriver driver){
	return driver.findElement(By.xpath("//select[@id='id_country']"));
}
public WebElement mobileNumber(WebDriver driver){
	return driver.findElement(By.xpath("//input[@id='phone_mobile']"));
}
public WebElement aliasAddress(WebDriver driver){
	return driver.findElement(By.xpath("//input[@id='alias']"));
}
public WebElement registerButton(WebDriver driver){
	return driver.findElement(By.xpath("//button[@id='submitAccount']"));
}

/*
 * Register User with the given inputs
 */
public void registerUser(WebDriver driver,String custFirstName,String custLastName,String password,String addrFirstName,String addrLastName,
		String addressLine1,String city,String state,String postalCode,String country,String mobileNumber,
		String aliasAddress){
	
	customerFirstName(driver).sendKeys(custFirstName);
	customerLastName(driver).sendKeys(custLastName);
	password(driver).sendKeys(password);
	addressFirstName(driver).sendKeys(addrFirstName);
	addressLastName(driver).sendKeys(addrLastName);
	addressLine1(driver).sendKeys(addressLine1);
	city(driver).sendKeys(city);
	Select selectState=new Select(state(driver));
	selectState.selectByVisibleText(state);
	postalCode(driver).sendKeys(postalCode);
	Select selectCountry=new Select(country(driver));
	selectCountry.selectByVisibleText(country);
	mobileNumber(driver).sendKeys(mobileNumber);
	aliasAddress(driver).sendKeys(aliasAddress);
	registerButton(driver).click();
}
}
