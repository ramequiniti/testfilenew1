package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage {
	/*
	 * Defining webElements of this page
	 */
public WebElement signInLink(WebDriver driver){
	return driver.findElement(By.xpath("//a[@class='login']"));
}
public WebElement createAccountEmailTxtBox(WebDriver driver){
	return driver.findElement(By.xpath("//input[@id='email_create']"));
}

public WebElement createAccountButton(WebDriver driver){
	return driver.findElement(By.xpath("//button[@id='SubmitCreate']"));
}
/*
 * Navigates to SigIn/SignUp Page
 */
public void navigateToSignInPage(WebDriver driver){
	try{
	signInLink(driver).click();
	WebDriverWait wait=new WebDriverWait(driver, 10);
	//WebElement waitElement=wait.until(ExpectedConditions.visibilityOf(createAccountEmailTxtBox(driver)));
	}
	catch(Exception e){
		System.out.println("Exception occurred while navigating to sign in page");
		e.printStackTrace();
	}
	}
/*
 * Navigates to user registration page by clicking on CREATE ACCOUNT button
 */
public void navigateToRegistrationPage(WebDriver driver,String emailID){
	try{
	createAccountEmailTxtBox(driver).sendKeys(emailID);
	createAccountButton(driver).click();
	Thread.sleep(2000);
	}
	catch(Exception e){
		System.out.println("Exception occurred while navigating to registration page");
		e.printStackTrace();
	}
	}

}
