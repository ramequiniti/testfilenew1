package util;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ReadPropertyFile {
public static String readFile(String key){
	String value="";
	try{
	File file=new File("C:\\Users\\admin\\workspace\\New folder\\Automation\\DataFiles\\Inputs.properties");
	FileInputStream fileReader=new FileInputStream(file);
	Properties propFile=new Properties();
	propFile.load(fileReader);
	value=propFile.getProperty(key);
	}
	catch(Exception e){
		System.out.println("Exception occured in reading file");
		e.printStackTrace();
	}
	return value;
}
}
