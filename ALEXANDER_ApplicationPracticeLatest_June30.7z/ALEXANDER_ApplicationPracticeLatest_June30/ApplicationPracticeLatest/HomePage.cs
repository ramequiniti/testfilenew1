﻿namespace ApplicationPracticeLatest.HomePageClasses
{
    using System;
    using System.Collections.Generic;
    using System.CodeDom.Compiler;
    using Microsoft.VisualStudio.TestTools.UITest.Extension;
    using Microsoft.VisualStudio.TestTools.UITesting;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
    using Mouse = Microsoft.VisualStudio.TestTools.UITesting.Mouse;
    using MouseButtons = System.Windows.Forms.MouseButtons;
    using System.Drawing;
    using System.Windows.Input;
    using System.Text.RegularExpressions;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
    
    
    
    public partial class HomePage
    {
        public bool? EnterSignIn()
        {

            bool? status = null; 
            try
            {
            
            HtmlHyperlink btn_SignIn = this.UIMyStoreInternetExploWindow.UIMyStoreDocument.UIHeaderCustom.UISigninHyperlink;
            Mouse.Click(btn_SignIn);
            Generic.WriteLog("<Information>","SignIn button clicked successfully " );
            status = true;

            }
            catch(Exception ex)
            {
                Generic.WriteLog("<Information>", "Failed to click SignIn button "+ex.Message);
                status = false;
            }

            return status;

        }

    }
}
