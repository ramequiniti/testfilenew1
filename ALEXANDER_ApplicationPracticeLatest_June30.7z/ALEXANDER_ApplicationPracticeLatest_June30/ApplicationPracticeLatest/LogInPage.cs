﻿namespace ApplicationPracticeLatest.LogInPageClasses
{
    using System;
    using System.Collections.Generic;
    using System.CodeDom.Compiler;
    using Microsoft.VisualStudio.TestTools.UITest.Extension;
    using Microsoft.VisualStudio.TestTools.UITesting;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
    using Mouse = Microsoft.VisualStudio.TestTools.UITesting.Mouse;
    using MouseButtons = System.Windows.Forms.MouseButtons;
    using System.Drawing;
    using System.Windows.Input;
    using System.Text.RegularExpressions;
    using System.IO;
    using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
    
    
    public partial class LogInPage
    {
        public enum themonths { jan , feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec };
        public bool? LogIn()
        {
            bool? status = null;
            try
            {
                Dictionary<string, string> Inputparameter = new Dictionary<string, string>();

                while (true)
                {
                    if (this.UILoginMyStoreInternetWindow.UIAddressBarClient.UIAddressandsearchusinEdit.Text == "http://automationpractice.com/index.php?controller=authentication&back=my-account#account-creation")
                    {
                        break;
                    }

                }

                Inputparameter = ReadInputFile();
                foreach (KeyValuePair<string, string> inputs in Inputparameter)
                {
                    if (!string.IsNullOrEmpty(inputs.Value))
                    {
                        switch (inputs.Key)
                        {

                            case "Title":
                                {
                                    HtmlLabel rb_Gender = null;
                                    if (inputs.Value.ToLower() == "mr")
                                    {
                                        rb_Gender = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIAccountcreation_formCustom.UIMRLabel;
                                    }
                                    else
                                    {
                                        rb_Gender = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIAccountcreation_formCustom.UIMrsLabel;
                                    }
                                    Mouse.Click(rb_Gender);
                                    status = true;
                                    Generic.WriteLog("information", "Successfully Selected tite as " + inputs.Value);
                                    break;
                                }
                            case "FirstName":
                                {
                                    HtmlEdit edt_FirstName = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIFirstnameEdit;
                                    edt_FirstName.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered FirstName as " + inputs.Value);
                                    break;
                                }
                            case "LastName":
                                {
                                    HtmlEdit edt_LastName = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UILastnameEdit;
                                    edt_LastName.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered LastName as " + inputs.Value);
                                    break;
                                }
                            case "Email":
                                {
                                    HtmlEdit edt_Email = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIEmailEdit;
                                    edt_Email.Text = inputs.Value;
                                    Generic.WriteLog("information", "Successfully entered email as " + inputs.Value);
                                    break;
                                }
                            case "PassWord":
                                {
                                    HtmlEdit edt_pwd = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIPasswordEdit;
                                    edt_pwd.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered password as " + inputs.Value);
                                    break;
                                }
                            case "DOBDate":
                                {
                                    HtmlComboBox cmb_date = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIDaysComboBox;
                                   cmb_date.SelectedIndex = Convert.ToInt32(inputs.Value);
                                    status = true;
                                    Generic.WriteLog("information", "Successfully selected date as " + inputs.Value);
                                    break;              
                                }
                            case "DOBMonth":
                                {
                                    HtmlComboBox cmb_month = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIMonthsComboBox;
                                    cmb_month.SelectedIndex = (2018 - Convert.ToInt32(inputs.Value));
                                     status = true;
                                    Generic.WriteLog("information", "Successfully selected month as " + inputs.Value);
                                    break;
                                }
                            case "DOBYear":
                                {
                                    HtmlComboBox cmb_year = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIYearsComboBox;
                                    Mouse.Click(cmb_year);
                                    HtmlListItem lst_Item = this.UIItemCustom.UIHttpautomationpractiDocument.UIItemListItem;
                                    lst_Item.SearchProperties[HtmlListItem.PropertyNames.InnerText] = inputs.Value;
                                    Mouse.Click(lst_Item); 
                                    status = true;
                                    Generic.WriteLog("information", "Successfully selected year as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressFirstName":
                                {
                                    HtmlEdit edt_AddressFName = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIFirstnameEdit1;
                                    edt_AddressFName.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered YourAddressFirstName as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressLastName":
                                {
                                    HtmlEdit edt_AddressFName = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UILastnameEdit1;
                                    edt_AddressFName.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered YourAddressLastName as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressCompany":
                                {
                                    HtmlEdit edt_AddressCompany = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UICompanyEdit;
                                    edt_AddressCompany.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered company as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressAddress":
                                {
                                    HtmlEdit edt_Address = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIAddressEdit;
                                    edt_Address.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered address as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressAddressLine2":
                                {
                                    HtmlEdit edt_Address2 = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIAddressLine2Edit;
                                    edt_Address2.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered address line 2 as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressCity":
                                {
                                    HtmlEdit edt_City = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UICityEdit;
                                    edt_City.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered address city as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressState":
                                {
                                    HtmlComboBox cmb_State = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIStateComboBox;
                                    cmb_State.SelectedIndex = 10;
                                    //HtmlListItem lst_Item = this.UIItemCustom.UIHttpautomationpractiDocument.UIItemListItem;
                                    //lst_Item.SearchProperties[HtmlListItem.PropertyNames.InnerText] = inputs.Value;
                                    //Mouse.Click(lst_Item);
                                    status = true;
                                    Generic.WriteLog("information", "Successfully selected state as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressPostalCode":
                                {
                                    HtmlEdit edt_PostalCode = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIZipPostalCodeEdit;
                                    edt_PostalCode.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered postal code as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressCountry":
                                {
                                    HtmlComboBox cmb_Country = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UICountryComboBox;
                                    cmb_Country.SelectedIndex = 10;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully selected country as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressAdditionalInformation":
                                {
                                    HtmlTextArea edt_Additional = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIAdditionalinformatioEdit;
                                    edt_Additional.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered additional address code as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressHomePhone":
                                {
                                    HtmlEdit edt_Additional = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIMobilephoneEdit;
                                    edt_Additional.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered Phone as " + inputs.Value);
                                    break;
                                }
                            case "YourAddressAddressAlias":
                                {
                                    HtmlEdit edt_Alias = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIAssignanaddressaliasEdit;
                                    edt_Alias.Text = inputs.Value;
                                    status = true;
                                    Generic.WriteLog("information", "Successfully entered Alias as " + inputs.Value);
                                    break;
                                }

                            default:
                                {
                                    Generic.WriteLog("error", "Invalid input " + inputs.Value);
                                }
                                break;
                        }
                    }
                    
                    
                }
                HtmlButton btn_finish = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIRegisterButton;
                Mouse.Click(btn_finish);
            }
            
            catch(Exception ex)
            {
                status = false;
                Generic.WriteLog("error", "Login Creation is failed " + ex.Message);
            }

            return status;
        }

        public Dictionary<string,string> ReadInputFile()
        {
            Dictionary<string, string> inputs = new Dictionary<string, string>();
            try
            {
                
                string[] aa = File.ReadAllLines(@"C:\Users\Test\Documents\Visual Studio 2013\Projects\ApplicationPracticeLatest\InputFile\InputFile.txt");
                foreach (string l in aa)
                {
                    string[] temp = l.Split(':');
                    inputs.Add(temp[0], temp[1]);
                }
            }
            catch (Exception ex)
            {
                
                Generic.WriteLog("error", "failed to read file " + ex.Message);
            }

            return inputs;
        }
    }
}
