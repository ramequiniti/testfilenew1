﻿using ApplicationPracticeLatest.HomePageClasses;
using ApplicationPracticeLatest.LogInMystoreClasses;
using ApplicationPracticeLatest.LogInPageClasses;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationPracticeLatest
{
    class Generic
    {
        public static string ErrorLogpath = null;
        public static string SummaryLogpath = null;
        public static void createLog()
        {
            try
            {
                ErrorLogpath = @"C:\Users\Test\Documents\Visual Studio 2013\Projects\ApplicationPracticeLatest\Logs\ErrorLogs\error.txt";
                SummaryLogpath = @"C:\Users\Test\Documents\Visual Studio 2013\Projects\ApplicationPracticeLatest\Logs\SummaryAndErrorLogs\summary.txt";
                if (!File.Exists(ErrorLogpath))
                {
                    File.Create(ErrorLogpath);
                    //TextWriter tw = new StreamWriter(path);
                    //tw.WriteLine("The very first line!");
                    //tw.Close();
                }
                if (!File.Exists(SummaryLogpath))
                {
                    File.Create(SummaryLogpath);
                }
            }
            catch(Exception ex)
            {
                WriteLog("error"," Exception caught on createLog "+ex.Message);
            }
            

        }

        public static void WriteLog(string LogType, string Message)
        {
            if(LogType.ToLower()=="error")
            {
                //using (StreamWriter writer = File.AppendText(ErorrLogpath));
                //{
                //    writer.WriteLine("line1");                    
                //}
                File.AppendAllText(ErrorLogpath,"<error>"+ Message+Environment.NewLine);
                File.AppendAllText(SummaryLogpath,"<error>" +Environment.NewLine);

            }
            else
            {                
                File.AppendAllText(SummaryLogpath, "<Information>"+ Message+Environment.NewLine );
            }
        }
        
        public static void StartTest()
        {
            createLog();
            HomePage home = new HomePage();
            LogInMystore loginstore = new LogInMystore();
            LogInPage loginPage = new LogInPage();
            home.EnterSignIn();
            loginstore.loginMystore();
            loginPage.LogIn();

        }
    }
}
