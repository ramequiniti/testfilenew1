﻿namespace ApplicationPracticeLatest.LogInMystoreClasses
{
    using System;
    using System.Collections.Generic;
    using System.CodeDom.Compiler;
    using Microsoft.VisualStudio.TestTools.UITest.Extension;
    using Microsoft.VisualStudio.TestTools.UITesting;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
    using Mouse = Microsoft.VisualStudio.TestTools.UITesting.Mouse;
    using MouseButtons = System.Windows.Forms.MouseButtons;
    using System.Drawing;
    using System.Windows.Input;
    using System.Text.RegularExpressions;
    using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
    
    
    public partial class LogInMystore
    {
        public bool? loginMystore()
        {
            bool? status = null;
            try
            {
                while (true)
                {
                    if (this.UILoginMyStoreInternetWindow.UIAddressBarClient.UIAddressandsearchusinEdit.Text == "http://automationpractice.com/index.php?controller=authentication&back=my-account")
                    {
                        break;
                    }

                }
                HtmlEdit edt_Address = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UIEmailaddressEdit;
                edt_Address.Text = "alexgowtham77@gmail.com";
                status = true;
                Generic.WriteLog("Information", "Succssfully entered address ");
                HtmlButton btn_CreateAcccount = this.UILoginMyStoreInternetWindow.UILoginMyStoreDocument.UICreateanaccountButton;
                Mouse.Click(btn_CreateAcccount);
                Generic.WriteLog("Information", "Succssfully clicked create new account");
                status = true; 
            }
            catch(Exception ex)
            {
                status = false;
                Generic.WriteLog("error", "failed on entering address or creating new account button "+ex.Message);
            }

            return status;
        }
    }
}
